#!/usr/bin/env python3
"""
Gradescope Autograder for CSE110 Lab 10 - Post Launch Tooling: User Analytics and Feedback
Graded out of 3 points total to match CSV export format
"""

import os
import json
import re
import sys
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple, Any

class Lab10Grader:
    def __init__(self):
        self.results = {
            "score": 0,
            "max_score": 3.0,
            "output": "",
            "tests": []
        }
        self.submission_dir = "/autograder/submission"
        self.test_dir = "/autograder/source/tests"
        
    def log(self, message: str, test_name: str = None, score: float = 0, max_score: float = 0, 
            status: str = "passed"):
        """Add test result to output"""
        if test_name:
            self.results["tests"].append({
                "name": test_name,
                "score": score,
                "max_score": max_score,
                "status": status,
                "output": message
            })
        else:
            self.results["output"] += message + "\n"
            
    def check_readme_exists(self) -> bool:
        """Check if README file exists in submission"""
        readme_files = ["README.md", "README.txt", "README"]
        for readme in readme_files:
            if os.path.exists(os.path.join(self.submission_dir, readme)):
                return True
        return False
    
    def extract_github_username(self) -> str:
        """Extract GitHub username from README or other files"""
        readme_paths = [
            os.path.join(self.submission_dir, "README.md"),
            os.path.join(self.submission_dir, "README.txt"),
            os.path.join(self.submission_dir, "README")
        ]
        
        for readme_path in readme_paths:
            if os.path.exists(readme_path):
                with open(readme_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    # Look for Canny.io URL pattern
                    canny_pattern = r'cse110-lab10-([a-zA-Z0-9_-]+)\.canny\.io'
                    match = re.search(canny_pattern, content)
                    if match:
                        return match.group(1)
        return None
    
    def check_canny_link_in_readme(self) -> bool:
        """Check if README contains link to Canny.io page"""
        readme_paths = [
            os.path.join(self.submission_dir, "README.md"),
            os.path.join(self.submission_dir, "README.txt"),
            os.path.join(self.submission_dir, "README")
        ]
        
        for readme_path in readme_paths:
            if os.path.exists(readme_path):
                with open(readme_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'canny.io' in content and 'cse110-lab10' in content:
                        return True
        return False
    
    def check_names_in_readme(self) -> bool:
        """Check if README contains names (at least 2 names)"""
        readme_paths = [
            os.path.join(self.submission_dir, "README.md"),
            os.path.join(self.submission_dir, "README.txt"),
            os.path.join(self.submission_dir, "README")
        ]
        
        for readme_path in readme_paths:
            if os.path.exists(readme_path):
                with open(readme_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
                    name_lines = 0
                    for line in lines:
                        words = line.strip().split()
                        if len(words) >= 2 and all(w[0].isupper() for w in words if w):
                            name_lines += 1
                    if name_lines >= 2:
                        return True
        return False
    
    def check_index_html_exists(self) -> bool:
        """Check if index.html exists"""
        index_path = os.path.join(self.submission_dir, "index.html")
        return os.path.exists(index_path)
    
    def check_ab_test_code(self) -> Tuple[bool, str]:
        """Check if A/B test JavaScript code is present in index.html"""
        index_path = os.path.join(self.submission_dir, "index.html")
        if not os.path.exists(index_path):
            return False, "index.html not found"
        
        with open(index_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        if 'Math.random()' not in content:
            return False, "Math.random() not found - needed for A/B testing"
        
        if 'classList.add' not in content or 'blue' not in content:
            return False, "classList.add('blue') not found"
        
        if 'querySelector' not in content and 'getElementById' not in content and 'body' not in content:
            return False, "Body element selection not found"
            
        return True, "A/B test code found"
    
    def check_google_analytics(self) -> Tuple[bool, str]:
        """Check if Google Analytics code is present in index.html"""
        index_path = os.path.join(self.submission_dir, "index.html")
        if not os.path.exists(index_path):
            return False, "index.html not found"
        
        with open(index_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        if 'gtag.js' not in content and 'analytics.js' not in content:
            return False, "Google Analytics script not found"
        
        ga_pattern = r'G-[A-Z0-9]+'
        if not re.search(ga_pattern, content):
            return False, "Google Analytics Measurement ID (G-XXXXXXXX) not found"
        
        return True, "Google Analytics code found"
    
    def check_screenshots_folder(self) -> bool:
        """Check if screenshots folder exists with google-analytics.png"""
        screenshots_path = os.path.join(self.submission_dir, "screenshots")
        if not os.path.exists(screenshots_path):
            return False
        
        png_path = os.path.join(screenshots_path, "google-analytics.png")
        if os.path.exists(png_path):
            return True
        
        png_files = list(Path(screenshots_path).glob("*.png"))
        return len(png_files) > 0
    
    def check_starter_files(self) -> int:
        """Check for presence of starter code files"""
        required_files = ["index.html", "styles.css", "script.js"]
        found_files = 0
        
        for file in required_files:
            if os.path.exists(os.path.join(self.submission_dir, file)):
                found_files += 1
                
        return found_files
    
    def run_git_check(self) -> Tuple[bool, str]:
        """Check if submission is a git repository and has proper commits"""
        try:
            os.chdir(self.submission_dir)
            result = subprocess.run(['git', 'log', '--oneline'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0 and len(result.stdout.strip().split('\n')) >= 1:
                return True, "Git repository found with commits"
            return False, "No git commits found"
        except:
            return False, "Not a git repository or git not available"
    
    def check_css_styling(self) -> Tuple[bool, str]:
        """Check for CSS styling including blue background class"""
        css_path = os.path.join(self.submission_dir, "styles.css")
        if not os.path.exists(css_path):
            return False, "styles.css not found"
        
        with open(css_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        if '.blue' in content and ('background' in content or 'background-color' in content):
            return True, ".blue class found with background styling"
        return False, ".blue class with background styling not found"
    
    def check_script_functionality(self) -> Tuple[bool, str]:
        """Check for basic JavaScript functionality"""
        script_path = os.path.join(self.submission_dir, "script.js")
        if not os.path.exists(script_path):
            return False, "script.js not found"
        
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        if 'addEventListener' in content or 'function' in content:
            return True, "JavaScript functionality found"
        return False, "No event listeners or functions found"
    
    def grade(self):
        """Main grading function - total 3 points max"""
        self.log("=== CSE110 Lab 10 Grader ===\n")
        self.log("Total points possible: 3.0\n")
        
        # Track points (each component is worth a fraction of 3.0)
        # Breakdown:
        # - README with Canny link and names: 1.0 point
        # - A/B test code: 0.5 point
        # - Google Analytics code: 0.5 point
        # - Screenshot: 0.5 point
        # - Starter files (all 3): 0.5 point
        total_points = 0.0
        
        # Check README (1.0 point)
        self.log("Checking README (1.0 point)...")
        readme_score = 0.0
        
        if self.check_readme_exists():
            if self.check_canny_link_in_readme() and self.check_names_in_readme():
                readme_score = 1.0
                self.log("✓ README found with Canny.io link and names", "README Complete", 1.0, 1.0)
            elif self.check_canny_link_in_readme():
                readme_score = 0.5
                self.log("⚠ README has Canny.io link but missing names (0.5/1.0)", "README Partial", 0.5, 1.0)
            elif self.check_names_in_readme():
                readme_score = 0.5
                self.log("⚠ README has names but missing Canny.io link (0.5/1.0)", "README Partial", 0.5, 1.0)
            else:
                self.log("✗ README exists but missing both Canny.io link and names (0/1.0)", "README Missing Info", 0, 1.0)
        else:
            self.log("✗ README file not found (0/1.0)", "README Missing", 0, 1.0)
        
        total_points += readme_score
        
        # Check A/B test code (0.5 point)
        self.log("\nChecking A/B test code (0.5 point)...")
        if self.check_index_html_exists():
            ab_test_status, ab_test_msg = self.check_ab_test_code()
            if ab_test_status:
                total_points += 0.5
                self.log("✓ A/B test code present: " + ab_test_msg, "A/B Test Code", 0.5, 0.5)
            else:
                self.log("✗ A/B test code missing: " + ab_test_msg, "A/B Test Code", 0, 0.5)
        else:
            self.log("✗ index.html not found - cannot check A/B test code", "A/B Test Code", 0, 0.5)
        
        # Check Google Analytics code (0.5 point)
        self.log("\nChecking Google Analytics code (0.5 point)...")
        if self.check_index_html_exists():
            ga_status, ga_msg = self.check_google_analytics()
            if ga_status:
                total_points += 0.5
                self.log("✓ Google Analytics code present: " + ga_msg, "Google Analytics", 0.5, 0.5)
            else:
                self.log("✗ Google Analytics code missing: " + ga_msg, "Google Analytics", 0, 0.5)
        else:
            self.log("✗ index.html not found - cannot check Google Analytics", "Google Analytics", 0, 0.5)
        
        # Check screenshot (0.5 point)
        self.log("\nChecking screenshot (0.5 point)...")
        if self.check_screenshots_folder():
            total_points += 0.5
            self.log("✓ Screenshots folder with analytics screenshot found", "Screenshots", 0.5, 0.5)
        else:
            self.log("✗ Screenshots folder or google-analytics.png not found", "Screenshots", 0, 0.5)
        
        # Check starter files (0.5 point) - need all 3 files for full credit
        self.log("\nChecking starter files (0.5 point)...")
        starter_files_found = self.check_starter_files()
        if starter_files_found == 3:
            total_points += 0.5
            self.log("✓ All 3 starter files found (index.html, styles.css, script.js)", "Starter Files", 0.5, 0.5)
        else:
            self.log(f"✗ Only {starter_files_found}/3 starter files found (0/0.5)", "Starter Files", 0, 0.5)
        
        # Optional: CSS styling check (informational only - no points)
        self.log("\n--- Additional Checks (Informational Only) ---")
        css_status, css_msg = self.check_css_styling()
        if css_status:
            self.log("ℹ CSS styling: " + css_msg)
        else:
            self.log("ℹ CSS styling issues: " + css_msg)
        
        js_status, js_msg = self.check_script_functionality()
        if js_status:
            self.log("ℹ JavaScript: " + js_msg)
        else:
            self.log("ℹ JavaScript issues: " + js_msg)
        
        git_status, git_msg = self.run_git_check()
        if git_status:
            self.log("ℹ " + git_msg)
        else:
            self.log("ℹ " + git_msg)
        
        # Set final score (rounded to 1 decimal place to match CSV)
        self.results["score"] = round(total_points, 1)
        
        # Add summary
        self.log(f"\n=== Total Score: {self.results['score']}/3.0 ===")
        
        # Grade breakdown
        self.log("\n--- Grade Breakdown ---")
        self.log(f"README (Canny link + names): {readme_score}/1.0")
        self.log(f"A/B test code: {0.5 if ab_test_status and self.check_index_html_exists() else 0}/0.5")
        self.log(f"Google Analytics: {0.5 if ga_status and self.check_index_html_exists() else 0}/0.5")
        self.log(f"Screenshot: {0.5 if self.check_screenshots_folder() else 0}/0.5")
        self.log(f"Starter files (all 3): {0.5 if starter_files_found == 3 else 0}/0.5")
        
        # Output results
        with open("/autograder/results/results.json", "w") as f:
            json.dump(self.results, f, indent=2)

if __name__ == "__main__":
    grader = Lab10Grader()
    grader.grade()